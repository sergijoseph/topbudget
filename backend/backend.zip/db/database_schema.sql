CREATE DATABASE budget;
USE budget;

CREATE TABLE users (
    user_id MEDIUMINT AUTO_INCREMENT NOT NULL,
    first_name VARCHAR(30) NOT NULL,
    last_name VARCHAR(30) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    started TINYINT(1) NOT NULL,
    verified TINYINT(1) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (user_id),
    UNIQUE (email)
);

CREATE TABLE accounts (
    account_id MEDIUMINT AUTO_INCREMENT NOT NULL,
    name VARCHAR(50) NOT NULL,
    user_id MEDIUMINT NOT NULL,
    PRIMARY KEY (account_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE categories (
    category_id MEDIUMINT AUTO_INCREMENT NOT NULL,
    name VARCHAR(50) NOT NULL,
    BUDGET_AMOUNT INT NOT NULL,
    user_id MEDIUMINT NOT NULL,
    PRIMARY KEY (category_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE transactions (
    transaction_id INT AUTO_INCREMENT NOT NULL,
    description VARCHAR(100) NOT NULL,
    amount INT NOT NULL,
    type ENUM('INCOME', 'EXPENSE') NOT NULL,
    date DATE NOT NULL,
    account_id MEDIUMINT NOT NULL,
    category_id MEDIUMINT NOT NULL,
    user_id MEDIUMINT NOT NULL,
    multi_trans_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (transaction_id),
    FOREIGN KEY (account_id) REFERENCES accounts(account_id),
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE transaction_allocations (
    allocation_id INT AUTO_INCREMENT NOT NULL,
    transaction_id INT NOT NULL,
    category_id MEDIUMINT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (allocation_id),
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id),
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

CREATE TABLE scheduled_trans (
    schedule_id INT AUTO_INCREMENT NOT NULL,
    description VARCHAR(100) NOT NULL,
    amount INT NOT NULL,
    type ENUM('INCOME', 'EXPENSE') NOT NULL,
    schedule_type ENUM('ONETIME', 'WEEKLY', 'MONTHLY') NOT NULL,
    date DATE NOT NULL,
    account_id MEDIUMINT NOT NULL,
    category_id MEDIUMINT NOT NULL,
    user_id MEDIUMINT NOT NULL,
    multi_trans_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (schedule_id),
    FOREIGN KEY (account_id) REFERENCES accounts(account_id),
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE refresh_tokens (
  jti_id VARCHAR(255) PRIMARY KEY,
  user_id MEDIUMINT NOT NULL,
  family_id VARCHAR(255) NOT NULL,
  status ENUM('valid', 'rotated', 'revoked') NOT NULL DEFAULT 'valid',
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  FOREIGN KEY (user_id) REFERENCES users(user_id)
);

INSERT INTO users (first_name, last_name, email, password, getting_started, verified)
VALUES ('Sergi', 'Joseph', 'test@email.com', 'asdfghjkl', 0, 0);\

UPDATE users
SET first_name = 'Terry', last_name = 'Jones'
WHERE user_id = 10;

ALTER TABLE users
RENAME COLUMN getting_started to started;

ALTER TABLE transactions
ADD COLUMN schedule_type ENUM('NONE', 'MONTHLY', 'WEEKLY') NOT NULL AFTER type;

ALTER TABLE transactions
MODIFY COLUMN schedule_type ENUM('NONE', 'MONTHLY-SD', 'MONTHLY-EOM', 'WEEKLY') NOT NULL;


SELECT   
t.transaction_id,
t.amount,
t.description,
t.date,
c.name AS category_name,
a.name AS account_name 
FROM transaction_allocations ta
JOIN categories c ON t.category_id = c.category_id
JOIN accounts a ON t.account_id = a.account_id
WHERE t.user_id = ? 
${includeCatId}
AND (t.date < ? OR (t.date = ? AND t.transaction_id < ?))
ORDER BY t.date DESC LIMIT ?

SELECT t.transaction_id, ta.amount, t.description, t.date, c.name AS category_name, a.name AS account_name
FROM transaction_allocations ta 
JOIN transactions t ON ta.transaction_id = t.transaction_id
JOIN categories c ON ta.category_id = c.category_id
JOIN accounts a ON t.account_id = a.account_id
WHERE t.user_id = 54
AND ta.category_id = 24
AND (t.date < ? OR (t.date = ? AND t.transaction_id < ?))
ORDER BY t.date DESC LIMIT 30
;


SELECT t.transaction_id, ta.amount, t.description, t.date, c.name AS category_name, a.name AS account_name
FROM transaction_allocations ta 
JOIN transactions t ON ta.transaction_id = t.transaction_id
JOIN categories c ON ta.category_id = c.category_id
JOIN accounts a ON t.account_id = a.account_id
WHERE t.user_id = 54
AND ta.category_id = 24
ORDER BY t.date DESC, t.transaction_id DESC LIMIT 2;

SELECT t.transaction_id, ta.amount, t.description, t.date, c.name AS category_name, a.name AS account_name
FROM transaction_allocations ta 
JOIN transactions t ON ta.transaction_id = t.transaction_id
JOIN categories c ON ta.category_id = c.category_id
JOIN accounts a ON t.account_id = a.account_id
WHERE t.user_id = 54
AND ta.category_id = 24
AND (t.date < '2025-09-25' OR (t.date = '2025-09-25' AND t.transaction_id < 123))
ORDER BY t.date DESC, t.transaction_id DESC LIMIT 2;

SELECT   
t.transaction_id,
t.amount,
t.description,
t.date,
c.name AS category_name,
a.name AS account_name 
FROM transactions t
JOIN categories c ON t.category_id = c.category_id
JOIN accounts a   ON t.account_id  = a.account_id
WHERE t.user_id = 54
ORDER BY t.date DESC, t.transaction_id DESC LIMIT 2


SELECT   
t.transaction_id,
t.amount,
t.description,
t.date,
c.name AS category_name,
a.name AS account_name
FROM transactions t
JOIN transaction_allocations ta ON t.transaction_id = ta.transaction_id
JOIN categories c ON ta.category_id = c.category_id
JOIN accounts a ON t.account_id  = a.account_id
WHERE t.user_id = 54
ORDER BY t.date DESC, t.transaction_id DESC LIMIT 2;

SELECT   
t.transaction_id,
t.amount,
t.description,
t.date,
a.name AS account_name,
CASE 
    WHEN COUNT(DISTINCT c.category_id) = 1 
        THEN MAX(c.name) 
    ELSE 'Multiple' 
END AS category_name
FROM transactions t
JOIN transaction_allocations ta ON ta.transaction_id = t.transaction_id
JOIN categories c ON ta.category_id = c.category_id
JOIN accounts a ON t.account_id  = a.account_id
WHERE t.user_id = 54
GROUP BY t.transaction_id, t.amount, t.description, t.date, a.name
ORDER BY t.date DESC, t.transaction_id DESC LIMIT 100;

SELECT   
t.transaction_id,
t.amount,
t.description,
t.date,
a.name AS account_name,
CASE 
    WHEN COUNT(DISTINCT c.category_id) = 1 
        THEN MAX(c.name) 
    ELSE 'Multiple' 
END AS category_name 
FROM transactions t
JOIN transaction_allocations ta ON t.transaction_id = ta.transaction_id
JOIN categories c ON ta.category_id = c.category_id
JOIN accounts a ON t.account_id = a.account_id
WHERE t.user_id = 54
AND (t.date < '2025-09-25' OR (t.date = '2025-09-25' AND t.transaction_id < 126))
GROUP BY t.transaction_id, t.amount, t.description, t.date, a.name
ORDER BY t.date DESC, t.transaction_id DESC LIMIT 2;

SELECT SUM(ta.amount) as total_income 
            FROM transaction_allocations ta
            JOIN transactions t ON ta.transaction_id = t.transaction_id
            WHERE t.user_id = 54 
            AND ta.category_id = 21
            AND t.type = 'INCOME'
            AND t.schedule_type = 'NONE'

SELECT SUM(ta.amount) as total_income 
            FROM transaction_allocations ta
            JOIN transactions t ON ta.transaction_id = t.transaction_id
            WHERE t.user_id = ? 
            AND ta.category_id = ?
            AND t.type = 'EXPENSE'
            AND t.schedule_type = 'NONE'            

SELECT   
t.transaction_id,
t.description,
t.amount,
t.date,
CASE 
    WHEN COUNT(DISTINCT c.category_id) = 1 
        THEN MAX(c.name) 
    ELSE 'Multiple' 
END AS category_name 
FROM transactions t
JOIN transaction_allocations ta ON t.transaction_id = ta.transaction_id
JOIN categories c ON ta.category_id = c.category_id
WHERE t.user_id = 54
AND t.schedule_type != 'NONE'
GROUP BY t.transaction_id, t.amount, t.description, t.date
ORDER BY t.date ASC;            

CREATE TABLE password_reset (
    id MEDIUMINT AUTO_INCREMENT NOT NULL,
    reset_code VARCHAR(40) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE password_reset
RENAME COLUMN created_at to expires_at;

ALTER TABLE password_reset
MODIFY COLUMN expires_at TIMESTAMP NOT NULL;

SELECT 
u.user_id
FROM password_reset pr
JOIN users u ON pr.email = u.email
WHERE pr.reset_code = '7b5414ed-6c69-4378-9795-85e20a1b7abd' AND pr.expires_at > '2025-10-12 20:10:20';

ALTER TABLE users
ADD COLUMN verification_code VARCHAR(40) NULL AFTER verified;